<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Enter your book</title>
  </head>
  <body>

  <form action="save-book.php" method="post">
    <div>
      <label for="title">Enter book title: </label>
      <input name="title" id="title">
    </div>
    <div>
      <label for="author">Enter book author: </label>
      <input name="author" id="author">
    </div>
    <div>
      <label for="year">Enter book year: </label>
      <input name="year" id="year">
    </div>
    <button>Submit</button>
  </form>
  </body>
</html>
